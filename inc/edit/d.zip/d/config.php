<?php 
//configurações do banco de dados
define('DB_HOST' , 'localhost');
define('DB_NAME' , 'u980950152_cadastro');
define('DB_USER' , 'u980950152_Ronaldo');
define('DB_PASS' , '#112208Ro');



?>